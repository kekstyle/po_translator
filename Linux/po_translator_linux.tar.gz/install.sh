#!/bin/bash
set -e

echo ""
echo "🔍 Vérification de l’environnement Python..."

# Vérifie que Python 3 est installé
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 n'est pas installé. Veuillez l'installer via votre gestionnaire de paquets."
    exit 1
fi

echo "✅ Python 3 est installé : $(python3 --version)"

# Vérifie la présence de tkinter
echo ""
echo "🔎 Vérification de tkinter..."
python3 -c "import tkinter" 2>/dev/null

if [ $? -eq 0 ]; then
    echo "✅ Tkinter est disponible"
else
    echo "⚠️ Tkinter n'est pas installé. Ajout via apt..."
    sudo apt update
    sudo apt install -y python3-tk
fi

# Installe les dépendances Python
echo ""
echo "📦 Installation des modules Python nécessaires..."
python3 -m pip install --user -r requirements.txt

echo ""
echo "🚀 Lancement de Po Translator..."
python3 po_translator.py
